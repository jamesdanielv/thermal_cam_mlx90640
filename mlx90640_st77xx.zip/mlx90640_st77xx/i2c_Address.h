#define MLX90640_address  0x33 //Default 7-bit unshifted address of the MLX90640
