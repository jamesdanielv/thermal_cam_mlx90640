//this just tells us mem method to use
#define NEW_METHOD true
#define USE_FAST_SQUARERT_METHOD true//if this is set to true uses a different method to roots.speed is debatable
#define MathreturnCacheAlorithum true //this takes advantage of math and eprom read redundancy
#define customSmallCacheForMemReads true //if true this creates a small cache for ram data reads. only works in NEW_METHOD mode. 
#define limitRangeofMath true //this fixes some calculations to allow working on 8bit processors. no effect on 32bit


#define Replace_detailed_calc_with_image_data false//this switched out complex ta calc for one that is only good enough for image results but should be faster using less math
#define autoNormalizeImageMode true //set to true to auto ajust sensativity range to approximate temp in c. good for image data only
#define NormalizeImageValue 1/16 //1/16 -1/256  this is if autoNormalize is set false. it limts the range that image mode is sensative at


#define serialbuffermode false //this is to test a serial buffer
#define outputSerial_ascii_graphics true //this is default to true. set to false if want better performance for lcd output

#define compressedSerialOutputBufferLevel0_3 0 //0 not used,1 =3072 bytes, 2 is 768 bytes, 3 is 96 bytes 


#define troubleshoot_optimize true //if true  output processing time per frameand holds for at least a second to read
//******************************lcd stuff below************************************
// adafruit ST7735R   it can be found also on amazon
//or sparkfun
#define cachebufferdataOnlyCalcValuesWhenChanges 0 //0 is off any other number is +/- amount for noise issues, for example a value of 16 higher numbers means changes less often
#define scale_of_temp_map 4 //this is how color temp is amplified. it should be below 255 values so 256/28.8deg as max is about 8. you can also use auto range
#define enhanced_precision 4 //we can increase resolution detail as well, but we need to compensate and lower scale. set to zero if not using displayv 2,4,8,16..
#define auto_scale false //we can switch to autoscale that makes the max level the sensor sees at max color range
