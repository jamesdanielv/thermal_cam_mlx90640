//Serial_Ascii_buffer.h
//raw data is loaded in buffer
//line by line in order by Serial_ascii_buffer_Val(x,y,store);
//if using compression mode values must be stored 
//as anly line at a time but the columb must be from smallest to largest
//read=Serial_ascii_buffer_In_Order_Read(x,y);
//Serial_ascii_fullbuffer_outputatOnce();sends all data to terminal
//including a clear screen (64 line returns)`
// just set x and y widths
//and compression level
//designed by james villeneuve do not remove above comments from code.
//all values input either float or int are converted into byte and only rance from 18-28 is used
//the raw char we use are ' ','-','+','x','O','0','#','@' for image and are from 18-28  
char ASCII_GPAHICS[8] ={' ','-','+','x','O','0','#','@'};  //;// ','-','+','x','O','0','#','@'}  //you can change what is show by replacing values in table
//    <---- Xres -----> Yres up/down

#define Xres    32 //raw row resolution not upsample. 32 value is max
#define Yres    24 //raw columb resolution not upsample this can be as small as 2 and max 254
#define DoubleResOutput true //this tells us output res data. this just allows us more accurate compression 
#define compression_level 0 //for testing 0 not compressed 1 stored in nibbles 1/2 space 2 actual compression





/////////////////********************************** the work is done here **********************************
#if compression_level == 0
char SerialBUffer[Xres*Yres];//this buffer can be quite big!
#else
uint32_t[Yres];//we store data in bits form of long words if compressed
byte data_read_cache;//we hold previous value to adjust algorithum
byte data_write_cache;
#endif 

void Serial_ascii_buffer_Val(uint8_t x_row,uint8_t y_col,uint8_t val){//this is routine we use to store data into buffer uncompressed
#if DoubleResOutput == true
uint8_t row =(x_row&63)>>1;//we get row and columb half doubleres
uint8_t col=(y_col>>6)>>1;//make 0-31 again every other data point
#else
uint8_t col =(x_row&31);//we get row and columb
uint8_t row=(y_col>>5);
#endif
byte oddvalueX=x_row &1;//if odd it is 1 if even it is 0
byte oddvalueY=y_col &1;//if odd it is 1 if even it is 0

//we only store values if not odd when running resolution doubled
#if DoubleResOutput == true //we only want even row and even col store when double active
if (oddvalueX==0 & oddvalueY==0){
#endif

//here is where we convert the values for storage
if (val<18){SerialBUffer[col*Xres+row]=0;}
if (val>18 &val<21){SerialBUffer[col*Xres+row]=1;}
if (val>20 &val<22){SerialBUffer[col*Xres+row]=2;}
if (val>21 &val<23){SerialBUffer[col*Xres+row]=3;}
if (val>22 &val<24){SerialBUffer[col*Xres+row]=4;}
if (val>23 &val<25){SerialBUffer[col*Xres+row]=5;}
if (val>24 &val<29){SerialBUffer[col*Xres+row]=6;}
if (val>28){SerialBUffer[col*Xres+row]=7;}
#if DoubleResOutput == true //if enabled then we have conditon that terminates here
}
#endif 





}

byte Serial_ascii_buffer_In_Order_Read(uint8_t x_row,uint8_t y_col){//this extracts  data from buffer
  byte data;//we use for sending data back
#if DoubleResOutput == true
uint8_t row =(x_row&63)>>1;//we get row and columb half doubleres
uint8_t col=(y_col>>6)>>1;//make 0-31 again every other data point
#else
uint8_t col =(x_row&31);//we get row and columb
uint8_t row=(y_col>>5);
#endif
byte oddvalueX=x_row &1;//if odd it is 1 if even it is 0
byte oddvalueY=y_col &1;//if odd it is 1 if even it is 0

//even bytes we show raw data, odd byte we show averaged data to next cell
#if DoubleResOutput != true
byte data=SerialBUffer[col*Xres+row];//raw data 
return ASCII_GPAHICS[data];//we sent data back from routine
#else //here is data doubleres
//this needs to be above 0 for each to work ok
if (oddvalueY==0){          
 //if y_col is even
  if (oddvalueX==0){data=SerialBUffer[col*Xres+row];}else{data=(SerialBUffer[col*Xres+row]+SerialBUffer[col*Xres+row-1]+1)>>1;}//even we get raw value, odd we get current value and value-1 avg
}else{// if y_col is odd
  if (oddvalueX==0){data=(SerialBUffer[col*Xres+row]+SerialBUffer[(col-1)*Xres+row]+1)>>1;}  //odd col, even row
  else{data=(((SerialBUffer[col*Xres+row]+SerialBUffer[(col-1)*Xres+row]+1)>>1 )+((SerialBUffer[col*Xres+row-1]+SerialBUffer[(col-1)*Xres+row-1]+1)>>1 )+1)>>1 ;}  
  
  }// if y_col is odd
ASCII_GPAHICS[data];//we return result for buffer
 #endif
}



/*
   if (temp< 18+offset) {Serial.print(F(". "));}
   if ((temp>17+offset) & (temp<21+offset)) {Serial.print(F(".-"));}
   if ((temp>20+offset) & (temp<22+offset)) {Serial.print(F(".+"));}
   if ((temp>21+offset) & (temp<23+offset)) {Serial.print(F(".X"));}
   if ((temp>22+offset) & (temp<24+offset)) {Serial.print(F(".O"));}
   if ((temp>23+offset) & (temp<25+offset)) {Serial.print(F(".0"));}
   if ((temp>24+offset) & (temp<29+offset)) {Serial.print(F(".#"));} 
   if (temp> 28+offset) {Serial.print(F(".@"));}

   */
