//this has some additonal values for testing output performance and output values


float alphaScale_testing;
float kvScale_testing;
float ktaScale1_testing;

float gainEE_testing;
