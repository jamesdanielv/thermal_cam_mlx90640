static float mlx90640To[768];//3072 bytes
